## python_visualisation
Data Scientist for Beginners

## Intro

파이썬을 활용한 데이터 시각화에 초점을 맞춘 강의안입니다. 강의 준비를 하면서 진행한 다양한 예제, 꿀팁 등으로 정리를 하여, 수강생들에게 도움을 주고자 합니다. 

## 시각화 주요 라이브러리 소개 및 설치 방법
### Matplotlib 라이브러리
파이썬 시각화 표준 라이브러리입니다. 객체 지향 프로그래밍을 지원하고, 2D 평면 그래프에 관한 다양한 포맷과 기능을 제공합니다. 설치 방법은 터미널 또는 윈도우 명령 프롬프트를 실행합니다. 

```bash
python -m pip install -U pip
python -m pip install -U matplotlib
```

그 외에 다양한 형태로 설치를 진행할 수 있습니다. [(개발자 버전)](https://matplotlib.org/3.1.1/users/installing.html)